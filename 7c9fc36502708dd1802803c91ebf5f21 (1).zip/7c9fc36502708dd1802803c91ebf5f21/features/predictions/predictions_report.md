# Continuous predictions

| feature   | model      |    acc |   auroc |   sens |   spec |     f1 |   bal_acc |
|:----------|:-----------|-------:|--------:|-------:|-------:|-------:|----------:|
| Variance  | sgd-linear | 0.8442 |  0.9198 | 0.8427 | 0.8295 | 0.8424 |    0.8427 |
| Skewness  | sgd-linear | 0.655  |  0.7528 | 0.6432 | 0.5377 | 0.6436 |    0.6432 |
| Curtosis  | sgd-linear | 0.6186 |  0.5447 | 0.583  | 0.2656 | 0.5529 |    0.583  |
| Variance  | dummy      | 0.556  |  0.5    | 0.5    | 0      | 0.3573 |    0.5    |
| Skewness  | dummy      | 0.556  |  0.5    | 0.5    | 0      | 0.3573 |    0.5    |
| Curtosis  | dummy      | 0.556  |  0.5    | 0.5    | 0      | 0.3573 |    0.5    |
| Entropy   | dummy      | 0.556  |  0.5    | 0.5    | 0      | 0.3573 |    0.5    |
| Entropy   | sgd-linear | 0.556  |  0.5413 | 0.5    | 0      | 0.3573 |    0.5    |



acc: accuracy
auroc: area under the receiving operater characteristic curve
sens: sensitivity
spec: specificity
