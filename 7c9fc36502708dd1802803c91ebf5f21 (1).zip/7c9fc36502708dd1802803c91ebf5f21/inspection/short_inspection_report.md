==================================================================================
                          Feature Cardinality Inferences                          
==================================================================================
Numeric Features
----------------

Continuous
┄┄┄┄┄┄┄┄┄┄
Skewness   All values are not integers and convert to float
Entropy    All values are not integers and convert to float
Variance   All values are not integers and convert to float
Curtosis   All values are not integers and convert to float

