# Wrapper-Based Feature Selection Summary

Wrapper model:  LGBM

## Selected Features

['Skewness', 'Curtosis']

## Selection scores (Importances: Larger magnitude = More important)

| feature   |     score |
|:----------|----------:|
| Variance  | 3.410e+02 |
| Skewness  | 4.400e+02 |
| Curtosis  | 3.950e+02 |
| Entropy   | 2.650e+02 |