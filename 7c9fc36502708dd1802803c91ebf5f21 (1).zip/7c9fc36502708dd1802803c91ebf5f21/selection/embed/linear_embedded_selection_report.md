# Wrapper-Based Feature Selection Summary

Wrapper model:  Linear

## Selected Features

['Variance', 'Skewness', 'Curtosis', 'Entropy']

## Selection scores (Coefficients: Larger magnitude = More important)

| feature   |      score |
|:----------|-----------:|
| Variance  | -4.557e+13 |
| Skewness  | -4.300e+13 |
| Curtosis  | -3.001e+13 |
| Entropy   | -2.480e+12 |