# Filter-Based Feature Selection Summary


## Selected Features

['Variance', 'Skewness']

## Selection Prediction Scores 

### Continuous Features (Accuracy: Higher = More important)

| feature   |       acc |
|:----------|----------:|
| Variance  | 2.882e-01 |
| Skewness  | 9.894e-02 |
| Curtosis  | 6.254e-02 |
| Entropy   | 0.000e+00 |

