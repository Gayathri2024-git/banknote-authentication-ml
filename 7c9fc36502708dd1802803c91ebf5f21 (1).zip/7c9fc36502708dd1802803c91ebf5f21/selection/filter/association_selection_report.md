# Filter-Based Feature Selection Summary


## Selected Features

['Variance__Class.1', 'Variance__Class.0', 'Skewness__Class.1', 'Skewness__Class.0', 'Curtosis__Class.0', 'Curtosis__Class.1', 'Entropy__Class.0', 'Entropy__Class.1']

## Selection Association Scores 

### Continuous Features (Mutual Information: Higher = More important)

|                   |   mut_info |
|:------------------|-----------:|
| Variance__Class.1 |  3.553e-01 |
| Variance__Class.0 |  3.549e-01 |
| Skewness__Class.1 |  2.305e-01 |
| Skewness__Class.0 |  2.293e-01 |
| Curtosis__Class.0 |  1.171e-01 |
| Curtosis__Class.1 |  1.166e-01 |
| Entropy__Class.0  |  2.280e-02 |
| Entropy__Class.1  |  2.250e-02 |

