# Wrapper-Based Feature Selection Summary

Wrapper method:    StepUp
Wrapper model:     Linear
Redundancy-aware:  True

## Selected Features

['Variance', 'Entropy', 'Curtosis']

## Selection Scores (Accuracy: Higher = More important)

| feature   |     score |
|:----------|----------:|
| Variance  | 8.398e-01 |
| Entropy   | 8.791e-01 |
| Curtosis  | 9.053e-01 |

# Redundant Stepwise Selection Results

Metric: Accuracy

* Variance (Accuracy=0.83985) - [Iteration   0]
* Entropy (Accuracy=0.87913) - [Iteration   1]
* Curtosis (Accuracy=0.90532) - [Iteration   2]
