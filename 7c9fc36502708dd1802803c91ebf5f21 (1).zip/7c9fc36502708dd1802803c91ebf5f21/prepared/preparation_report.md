# Data Preparation Summary

Task:                   Classification
Data original shape:    1373 samples × 5 features
Data final shape:       1373 samples × 4 features
Target feature:         Class

Samples dropped due to NaN target: 0
Indicator variables added for continuous NaNs: 0

# Processing Times

| computation          |   runtime (ms) |
|:---------------------|---------------:|
| unify_nans           |              4 |
| convert_categoricals |              0 |
| inspect_target       |              2 |
| drop_target_nans     |              1 |
| encode_target        |              2 |
| drop_unusable        |              5 |
| deflate_categoricals |              0 |
| encode_categoricals  |             17 |